package com.joel_lah.examen_001.repositories;

import com.joel_lah.examen_001.models.Song;

public interface SongRepository extends BaseRepository<Song>{
    
}

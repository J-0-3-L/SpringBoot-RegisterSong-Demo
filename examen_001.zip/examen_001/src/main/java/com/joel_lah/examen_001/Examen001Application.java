package com.joel_lah.examen_001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Examen001Application {

	public static void main(String[] args) {
		SpringApplication.run(Examen001Application.class, args);
	}

}
